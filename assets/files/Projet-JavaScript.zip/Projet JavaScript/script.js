var tabCouleur = ["red", "blue", "green", "yellow", "orange", "purple", "pink", "cyan", "dodgerblue", "gray"];

function animer(){
    var count = 0;
    
    var temps = setInterval(function(){
        
        var i = Math.floor(count/10);
        var j = count%10;

        var couleur = tabCouleur[Math.floor(Math.random() * tabCouleur.length)];

        var carre = document.getElementById(""+i+j);
        carre.style.backgroundColor = couleur;
    
        count += 1;
        
        if(count == 100){
            clearInterval(temps);
        }
        
    }, 100);
}