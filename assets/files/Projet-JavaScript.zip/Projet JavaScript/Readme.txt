Participants: 
- Mamadou TOURE
- Mamadou SECK
- Sokhna Dialel BA

Professeur: Mr NGUER

Dans ce projet, on a créé un tableau de 10 lignes et 10 colonnes.

Chaque case du tableau possède un id pour pouvoir la modifier avec document.getElementByID

Pour faire l’animation, on a utilisé :

- setInterval() pour répéter la fonction chaque 100ms
- clearInterval() pour arrêter l’animation à la fin
- un tableau contenant 10 couleurs différentes
- l’opérateur modulo pour parcourir le tableau et changer automatiquement la couleur des cases pendant l’animation

Nous avons aussi téléchargé une image sur Internet pour représenter le bouton "Start". Quand on clique dessus, la fonction se déclenche comme demandé dans le projet.

Vous souhaitant bonne réception!