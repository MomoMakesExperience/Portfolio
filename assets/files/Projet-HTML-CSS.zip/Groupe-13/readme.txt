README

Présentation du projet
Le projet consistait en la création d’un mini site web suivant le cahier des charges défini par notre enseignant, M. Dione, à l’issue du module sur la programmation Internet côté client.

Porteurs du projet
- M. Mamadou TOURE
- M. Mamadou SECK

Choix du thème et justification
Thème choisi : « Intelligences artificielles : Des outils pour nous simplifier la vie ! »
Nous avons retenu ce thème car l’IA, considérée comme la 4e révolution technologique, est aujourd’hui au cœur de l’actualité mondiale.
- Elle intervient dans presque tous les secteurs : usages domestiques, administrations, entreprises privées, gouvernements.
- Elle permet l’automatisation, la résolution de problèmes complexes et la réalisation de tâches autrefois impossibles.
- Son rôle ne cesse de croître de façon exponentielle, d’où la pertinence de l’intégrer à notre projet.

Objectifs du projet
- Pour l’enseignant : vérifier notre compréhension, assimilation et capacité de mise en pratique des notions enseignées.
- Pour nous étudiants : tester nos compétences, appliquer les acquis et renforcer notre maîtrise du HTML/CSS.

Réalisation : ressources et moyens utilisés
Langages utilisés : HTML et CSS.

Principaux concepts utilisés :
- Iframes, listes, tableaux, descriptive list, formulaires
- Balises sémantiques
- Balises <div> et <span>
- Propriétés CSS : display: Flex, margin, padding, background-image
- Balises vides (<hr>, <br>)
- Liens externes et signets

on a veillé aussi a la lisibilité du code les imbrications & indentations

Justification de l’usage de <div> et <span> :
Elles nous ont permis d’organiser l’espace, de regrouper des éléments partageant les mêmes propriétés et d’appliquer des classes communes là où les balises sémantiques seules ne suffisaient pas.

Lieu et période
Projet réalisé à Saint-Louis du 10 août au 26 août 2025.

Contenu et limites du site
Étant donné l’ampleur du sujet, nous avons limité le contenu à :
- Définitions, types d’IA et sous-disciplines
- Fonctionnement des IA
- Applications sectorielles (utilité et impact concret dans différents domaines)
- Conseils et recommandations pour un usage optimal des outils d’IA
- Impact sur l’emploi (emplois menacés, nouveaux métiers créés, emplois résilients)

Nous avons également intégré une vision évolutive du site : possibilité de mises à jour périodiques pour suivre les avancées rapides du secteur et enrichir les exemples d’applications.

Toutes les informations sont documentées et référencées.


